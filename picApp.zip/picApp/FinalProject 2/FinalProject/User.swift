//
//  User.swift
//  FinalProject
//
//  Created by mac on י״ב בשבט תשע״ז.
//  Copyright © 5777 mac. All rights reserved.
//

import Foundation
class User {
    
    var uid:String
    var name:String
    
    init(_ uid:String,_ name:String) {
        self.uid = uid
        self.name = name
        
    }
    
}
